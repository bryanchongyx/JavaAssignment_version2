import java.util.ArrayList;
import java.util.List;

public class Hall {
    private String hallName;
    private String hallType;
    private int capacity;
    private double ratePerHour;
    //private List<Availability> availabilityList;

    
    public Hall (String hallName, String hallType, int capacity, double ratePerHour){
        this.hallName = hallName;
        this.hallType = hallType;
        this.capacity = capacity;
        this.ratePerHour = ratePerHour;
        //this.availabilityList  = new ArrayList<>();
    }


    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(double ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
    
    /*public List<Availability> getAvailabilityList() {
        return availabilityList;
    }

    public void setAvailabilityList(List<Availability> availabilityList) {
        this.availabilityList = availabilityList;
    }
    
    public void addAvailability(Availability availability) {
        availabilityList.add(availability);
    }*/


    
    
}
