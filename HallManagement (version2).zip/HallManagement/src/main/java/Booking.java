
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Booking {
    private String bookingId;
    private String userid;
    private String fullname;
    private String ph_number;
    private String email;
    private String hallType;    // Type of hall (e.g., Auditorium, Banquet Hall)
    private String hallName;    // Name of the hall
    private int capacity;       // Capacity of the hall
    private double ratePerHour; // Hourly rate of the hall
    private String date;        // Date of availability
    private String startTime;   // Start time of availability slot
    private String endTime;     // End time of availability slot
    private String bookedDate;  // Date of booking
    private Double price;       // Total price of the booking
    private String status;      // e.g., "Booked", "Cancelled"

    public Booking(String bookingId, String userid, String fullname, String ph_number, String email, String hallType, String hallName, int capacity, double ratePerHour, String date, String startTime, String endTime, String bookedDate,Double price, String status) {
        this.bookingId = generateBookingId();
        this.userid = userid;
        this.fullname = fullname;
        this.ph_number = ph_number;
        this.email = email;
        this.hallType = hallType;
        this.hallName = hallName;
        this.capacity = capacity;
        this.ratePerHour = ratePerHour;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bookedDate = bookedDate;
        this.price = calculatePrice(ratePerHour, startTime, endTime); // Calculate price
        this.status = status;
    }

    // Method to calculate total price
    private double calculatePrice(double ratePerHour, String startTime, String endTime) {
        int hours = calculateHours(startTime, endTime);
        return hours * ratePerHour;
    }

    // Method to calculate hours based on start and end time
    private int calculateHours(String startTime, String endTime) {
        String[] start = startTime.split(":");
        String[] end = endTime.split(":");
        int startHour = Integer.parseInt(start[0]);
        int endHour = Integer.parseInt(end[0]);
        return endHour - startHour; // Assuming duration is in whole hours
    }

    // Getters and setters
    public double getPrice() {
        return price;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPh_number() {
        return ph_number;
    }

    public void setPh_number(String ph_number) {
        this.ph_number = ph_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(double ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getBookedDate() {
        return bookedDate;
    }

    public void setBookedDate(String bookedDate) {
        this.bookedDate = bookedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getBookingId(){
        return bookingId;
    }
    
    public void setBookingId(String bookingId){
        this.bookingId = bookingId;
    }
    
     private String generateBookingId() {
        int lastId = getLastBookingId();
        return "BKG" + (lastId + 1);
    }

    private int getLastBookingId() {
        int lastId = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader("booking.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Assuming booking.txt has each booking record in one line and bookingId is the first field
                String[] fields = line.split(",");
                if (fields.length > 0 && fields[0].startsWith("BKG")) {
                    String bookingId = fields[0].substring(3); // Remove "BKG" prefix
                    try {
                        int id = Integer.parseInt(bookingId);
                        if (id > lastId) {
                            lastId = id;
                        }
                    } catch (NumberFormatException e) {
                        // Skip any malformed booking IDs
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading booking file: " + e.getMessage());
        }
        return lastId;
    }
}

