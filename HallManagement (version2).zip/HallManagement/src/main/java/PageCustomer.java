
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class PageCustomer implements ActionListener{
    JFrame a;
    JButton edit, booking, bookingManagement, logout;
    Customer customer;
    
    public PageCustomer (Customer customer){
        this.customer = customer;
        a =new JFrame ("Customer Dashboard");
        a.setSize (300,300);
        a.setLayout (new FlowLayout());
        a.setLocationRelativeTo(null);
        
        edit = new JButton ("Edit Own Profile");
        booking  = new JButton ("Make Booking");
        bookingManagement = new JButton ("Booking Management");
        logout = new JButton ("Logout");
        
        edit.addActionListener(this);
        booking.addActionListener(this);
        bookingManagement.addActionListener(this);
        logout.addActionListener(this);
        
        a.add (booking);
        a.add(bookingManagement);
        a.add (edit);
        a.add (logout);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    @Override
    public void actionPerformed (ActionEvent e){
        if (e.getSource() == booking){
            a.setVisible(false);
            if (Main.a14 == null) {
                Main.a14 = new PageHallBooking(customer, this);
            }
            Main.a14.showPage();
        }
        else if (e.getSource () == bookingManagement){
            a.setVisible(false);
            if (Main.a15 == null){
                Main.a15 = new PageBookingManagement (customer, this);
            }
            Main.a15.showPage();
        }
        else if (e.getSource () == edit){
            a.setVisible (false);
            if (Main.a16== null){
                Main.a16 = new PageEditCustomerProfile (customer, this);
                
            }
            Main.a16.showPage();
 
        }
        else if (e.getSource () == logout){
            a.setVisible(false);
            Main.a1.a.setVisible(true);
        }
    }
}
