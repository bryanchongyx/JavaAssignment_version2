import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PageEditCustomerProfile implements ActionListener {
    JFrame a;
    JTextField fullnameField, useridField, emailField, phNumberField;
    JPasswordField passwordField;
    JButton saveButton, cancelButton;
    JCheckBox showPasswordCheckbox;
    Customer customer;
    PageCustomer customerPage;

    public PageEditCustomerProfile(Customer customer, PageCustomer customerPage) {
        this.customer = customer;
        this.customerPage = customerPage;
        a = new JFrame("Edit Profile");
        a.setSize(400, 350);
        a.setLayout(new GridBagLayout());
        a.setLocationRelativeTo(null);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Create fields
        fullnameField = new JTextField(customer.getFullname());
        useridField = new JTextField(customer.getUserid());
        passwordField = new JPasswordField(customer.getPassword());
        emailField = new JTextField(customer.getEmail());
        phNumberField = new JTextField(customer.getPh_number());

        // Add components to the frame with GridBagConstraints
        gbc.gridx = 0; gbc.gridy = 0;
        a.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        a.add(fullnameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        a.add(new JLabel("User ID:"), gbc);
        gbc.gridx = 1;
        a.add(useridField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        a.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        a.add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        a.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        a.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        a.add(new JLabel("Phone Number:"), gbc);
        gbc.gridx = 1;
        a.add(phNumberField, gbc);

        // Show password checkbox
        gbc.gridx = 1; gbc.gridy = 5;
        showPasswordCheckbox = new JCheckBox("Show Password");
        showPasswordCheckbox.setBackground(Color.WHITE);
        showPasswordCheckbox.addActionListener(this);
        a.add(showPasswordCheckbox, gbc);

        // Create buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");
        saveButton.addActionListener(this);
        cancelButton.addActionListener(this);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        a.add(buttonPanel, gbc);

        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.setVisible(true);
    }
    
    public void showPage(){
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveButton) {
            saveProfile();
        } else if (e.getSource() == cancelButton) {
            a.dispose(); // Close the edit profile window
            customerPage.a.setVisible(true);
        } else if (e.getSource() == showPasswordCheckbox) {
            if (showPasswordCheckbox.isSelected()) {
                showPassword();
            } else {
                hidePassword();
            }
        }
    }

    private void saveProfile() {
        try {
            // Store original UserID
            String currentUserid = customer.getUserid();

            // Get input values
            String newFullname = fullnameField.getText().trim();
            String newUserid = useridField.getText().trim();
            String newPassword = new String(passwordField.getPassword()).trim();
            String newEmail = emailField.getText().trim();
            String newPhNumber = phNumberField.getText().trim();

            // Check for empty input fields
            if (newFullname.isEmpty()) {
                throw new Exception("Full Name cannot be empty!");
            }
            if (newUserid.isEmpty()) {
                throw new Exception("User ID cannot be empty!");
            }
            if (newPassword.isEmpty()) {
                throw new Exception("Password cannot be empty!");
            }
            if (newEmail.isEmpty()) {
                throw new Exception("Email cannot be empty!");
            }
            if (newPhNumber.isEmpty()) {
                throw new Exception("Phone Number cannot be empty!");
            }

            // Validate email format
            if (!newEmail.contains("@") || !newEmail.endsWith(".com")) {
                throw new Exception("Invalid email format! Email must contain '@' and end with '.com'.");
            }

            // Validate phone number (must be 10 digits)
            if (!newPhNumber.matches("\\d{10}")) {
                throw new Exception("Invalid phone number! Phone number must be exactly 10 digits.");
            }

            // Check if the new User ID is already taken, if different from current User ID
            if (!newUserid.equals(currentUserid) && DataIO.checkUserid(newUserid) != null) {
                throw new Exception("User ID is already taken!");
            }

            // Update Fullname, Password, Email, and Phone Number
            customer.setFullname(newFullname);
            customer.setPassword(newPassword);
            customer.setEmail(newEmail);
            customer.setPh_number(newPhNumber);

            // Save updates in the data source
            DataIO.updateCustomerFullname(currentUserid, newFullname);
            DataIO.updateCustomerPassword(currentUserid, newPassword);
            DataIO.updateCustomerEmail(currentUserid, newEmail);
            DataIO.updateCustomerPhNumber(currentUserid, newPhNumber);

            // Update UserID if it has changed
            if (!newUserid.equals(currentUserid)) {
                customer.setUserid(newUserid);
                DataIO.updateCustomerUserid(currentUserid, newUserid);
            }

            // Save changes to the data source
            DataIO.write(); // Implement this method to save updated customer data

            JOptionPane.showMessageDialog(a, "Profile updated successfully!");
            clearFields();
            a.dispose(); // Close the window after saving
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(a, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Method to show password
    private void showPassword() {
        passwordField.setEchoChar((char) 0); // Remove masking
    }

    // Method to hide password
    private void hidePassword() {
        passwordField.setEchoChar('*'); // Set masking character
    }

    private void clearFields() {
        fullnameField.setText("");
        useridField.setText("");
        passwordField.setText("");
        emailField.setText("");
        phNumberField.setText("");
        showPasswordCheckbox.setSelected(false); // Reset checkbox
        hidePassword(); // Hide password when clearing fields
    }
}
