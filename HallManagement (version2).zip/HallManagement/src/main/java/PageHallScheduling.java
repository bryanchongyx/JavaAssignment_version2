import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.table.TableRowSorter;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;
import org.jdatepicker.DateLabelFormatter;
import org.jdatepicker.impl.JDatePanelImpl;

public class PageHallScheduling implements ActionListener {
    JFrame a;
    JTable availabilityTable;
    DefaultTableModel tableModel;
    JButton addButton, editButton, deleteButton, backButton;
    JComboBox<String> hallTypeDropdown, hallDropdown;
    JDatePickerImpl datePicker;
    JComboBox<String> startTimeDropdown, endTimeDropdown, statusDropdown;
    TableRowSorter<DefaultTableModel> rowSorter;
    PageScheduler schedulerPage;

    public PageHallScheduling(PageScheduler schedulerPage) {
        this.schedulerPage = schedulerPage;
        a = new JFrame("Hall Scheduling");
        a.setSize(1000, 600);
        a.setLayout(new BorderLayout());
        a.setLocationRelativeTo(null);

        // Table for displaying availability
        String[] columns = {"Select", "Hall Type", "Hall Name", "Capacity", "Rate Per Hour (RM)", "Date", "Start Time", "End Time", "Status", "Price (RM)"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) { // Select column
                    return Boolean.class; // Set the first column to Boolean class
                }
                return super.getColumnClass(columnIndex);
            }
        };

        availabilityTable = new JTable(tableModel); // Initialize the table
        rowSorter = new TableRowSorter<>(tableModel);
        availabilityTable.setRowSorter(rowSorter);

        JScrollPane scrollPane = new JScrollPane(availabilityTable);
        a.add(scrollPane, BorderLayout.CENTER);

        // Hall Type Dropdown
        hallTypeDropdown = new JComboBox<>(new String[]{"Auditorium", "Banquet Hall", "Meeting Room"});
        hallTypeDropdown.addActionListener(this);

        // Hall Dropdown
        hallDropdown = new JComboBox<>(getFilteredHallNames((String) hallTypeDropdown.getSelectedItem()));

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(7, 2));
        inputPanel.add(new JLabel("Select Hall Type:"));
        inputPanel.add(hallTypeDropdown);
        inputPanel.add(new JLabel("Select Hall:"));
        inputPanel.add(hallDropdown);

        // Date Picker
        UtilDateModel model = new UtilDateModel();
        Properties properties = new Properties();
        properties.put("text.today", "Today");
        properties.put("text.month", "Month");
        properties.put("text.year", "Year");
        datePicker = new JDatePickerImpl(new JDatePanelImpl(model, properties), new DateLabelFormatter());
        inputPanel.add(new JLabel("Select Date:"));
        inputPanel.add(datePicker);

        // Start Time Dropdown
        startTimeDropdown = new JComboBox<>(getTimeSlots());
        inputPanel.add(new JLabel("Start Time:"));
        inputPanel.add(startTimeDropdown);

        // End Time Dropdown
        endTimeDropdown = new JComboBox<>(getTimeSlots());
        inputPanel.add(new JLabel("End Time:"));
        inputPanel.add(endTimeDropdown);

        // Status Dropdown
        statusDropdown = new JComboBox<>(new String[]{"Available", "Under Maintenance"});
        inputPanel.add(new JLabel("Status:"));
        inputPanel.add(statusDropdown);

        a.add(inputPanel, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        backButton = new JButton("Back");

        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        backButton.addActionListener(this);

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);
        a.add(buttonPanel, BorderLayout.SOUTH);

        loadAvailabilityData(); // Load the data into the table

        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void showPage() {
        a.setVisible(true); // Make the frame visible
    }

    private String[] getFilteredHallNames(String hallType) {
        // Filter hall names by hall type from the hall.txt file
        ArrayList<String> hallNames = new ArrayList<>();
        for (Hall hall : DataIO.allHall) {
            if (hall.getHallType().equals(hallType)) {
                hallNames.add(hall.getHallName());
            }
        }
        return hallNames.toArray(new String[0]);
    }

    private String[] getTimeSlots() {
        String[] timeSlots = new String[11]; // 8 AM to 6 PM
        for (int i = 0; i < 11; i++) {
            int hour = 8 + i;
            timeSlots[i] = String.format("%02d:00", hour);
        }
        return timeSlots;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            String hallType = (String) hallTypeDropdown.getSelectedItem();
            String hallName = (String) hallDropdown.getSelectedItem();
            String date = datePicker.getJFormattedTextField().getText().trim();
            String startTime = (String) startTimeDropdown.getSelectedItem();
            String endTime = (String) endTimeDropdown.getSelectedItem();
            String status = (String) statusDropdown.getSelectedItem();

            if (!hallName.isEmpty() && !date.isEmpty() && startTime != null && endTime != null && status != null) {
                if (startTime.equals(endTime)) {
                    JOptionPane.showMessageDialog(a, "Start time and end time cannot be the same.");
                    return;
                }

                if (endTime.compareTo(startTime) <= 0) {
                    JOptionPane.showMessageDialog(a, "End time must be later than start time.");
                    return;
                }

                // Check for overlapping availability
                if (!isTimeAvailable(hallName, date, startTime, endTime, -1)) {
                    JOptionPane.showMessageDialog(a, "The selected time overlaps with existing availability.");
                    return;
                }

                int capacity = DataIO.getHallCapacity(hallName);
                double ratePerHour = DataIO.getHallRate(hallName);
                Double price = calculatePrice(ratePerHour, startTime, endTime, status);

                if (price == null) {
                    price = 0.0; // Represent 'N/A' with 0.0 for unavailable halls
                }

                DataIO.allAvailability.add(new Availability(hallType, hallName, capacity, ratePerHour, date, startTime, endTime, status, price));
                DataIO.write(); // Write availability to a file
                loadAvailabilityData();
                HallAvailabilityUpdater.updateAvailability();
                JOptionPane.showMessageDialog(a, "Availability added successfully.");
            } else {
                JOptionPane.showMessageDialog(a, "Please fill in all fields.");
            }
        } else if (e.getSource() == editButton) {
            // Collect checked rows
            ArrayList<Integer> selectedRows = new ArrayList<>();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if ((Boolean) tableModel.getValueAt(i, 0)) {
                    selectedRows.add(i);
                }
            }

            if (selectedRows.isEmpty()) {
                JOptionPane.showMessageDialog(a, "Please select at least one row to edit.");
                return;
            } else if (selectedRows.size() > 1) {
                JOptionPane.showMessageDialog(a, "Please select only one row to edit.");
                return;
            }

            int selectedRow = selectedRows.get(0);
            String hallType = (String) hallTypeDropdown.getSelectedItem();
            String hallName = (String) hallDropdown.getSelectedItem();
            String date = datePicker.getJFormattedTextField().getText().trim();
            String startTime = (String) startTimeDropdown.getSelectedItem();
            String endTime = (String) endTimeDropdown.getSelectedItem();
            String status = (String) statusDropdown.getSelectedItem();

            if (!hallName.isEmpty() && !date.isEmpty() && startTime != null && endTime != null && status != null) {
                if (startTime.equals(endTime)) {
                    JOptionPane.showMessageDialog(a, "Start time and end time cannot be the same.");
                    return;
                }

                if (endTime.compareTo(startTime) <= 0) {
                    JOptionPane.showMessageDialog(a, "End time must be later than start time.");
                    return;
                }

                // Check for overlapping availability, ignoring the currently edited row
                if (!isTimeAvailable(hallName, date, startTime, endTime, selectedRow)) {
                    JOptionPane.showMessageDialog(a, "The selected time overlaps with existing availability.");
                    return;
                }

                int capacity = DataIO.getHallCapacity(hallName);
                double ratePerHour = DataIO.getHallRate(hallName);
                Double price = calculatePrice(ratePerHour, startTime, endTime, status);

                if (price == null) {
                    price = 0.0; // Represent 'N/A' with 0.0 for unavailable halls
                }

                Availability updatedAvailability = new Availability(hallType, hallName, capacity, ratePerHour, date, startTime, endTime, status, price);
                DataIO.allAvailability.set(selectedRow, updatedAvailability);
                DataIO.write(); // Write availability to a file
                loadAvailabilityData();
                JOptionPane.showMessageDialog(a, "Availability updated successfully.");
            } else {
                JOptionPane.showMessageDialog(a, "Please fill in all fields.");
            }
        } else if (e.getSource() == deleteButton) {
            ArrayList<Integer> rowsToDelete = new ArrayList<>();
            boolean hasInvalidStatus = false; // Flag to track if there's an entry that can't be deleted

            // Check if exactly one row is selected
            for (int i = 0; i < availabilityTable.getRowCount(); i++) {
                boolean isSelected = (boolean) availabilityTable.getValueAt(i, 0);
                if (isSelected) {
                    if (rowsToDelete.size() >= 1) {
                        JOptionPane.showMessageDialog(a, "Please select only one row to delete.");
                        return; // Exit if more than one row is selected
                    }
                    String status = (String) availabilityTable.getValueAt(i, 8); // Assuming the status is in the 8th column (index 7)

                    if (status.equals("Booked")) {
                        JOptionPane.showMessageDialog(a, "Cannot delete: the hall is booked.");
                        return; // Exit if the selected hall is booked
                    } else if (status.equals ("Under Maintenance")){
                        JOptionPane.showMessageDialog (a, "Cannot delete: Hall is under maintenance.");
                        return;
                    }
                    else {
                        rowsToDelete.add(i); // Collect the index of the selected row if it can be deleted
                    }
                }
            }

            if (rowsToDelete.isEmpty()) {
                JOptionPane.showMessageDialog(a, "Please select a row to delete.");
                return;
            }

            // Proceed to delete the selected row
            for (int i = rowsToDelete.size() - 1; i >= 0; i--) {
                DataIO.allAvailability.remove((int) rowsToDelete.get(i));
            }
            DataIO.write(); // Write availability to a file
            loadAvailabilityData(); // Refresh the table data
            JOptionPane.showMessageDialog(a, "Selected availability deleted successfully.");

        } else if (e.getSource() == hallTypeDropdown) {
            // Update hall dropdown based on selected hall type
            hallDropdown.setModel(new DefaultComboBoxModel<>(getFilteredHallNames((String) hallTypeDropdown.getSelectedItem())));
        } else if (e.getSource() == backButton) {
            a.setVisible(false);
            schedulerPage.a.setVisible(true);
        }
    }

    private boolean isTimeAvailable(String hallName, String date, String startTime, String endTime, int ignoreRowIndex) {
        for (int i = 0; i < DataIO.allAvailability.size(); i++) {
            Availability availability = DataIO.allAvailability.get(i);
            if (i == ignoreRowIndex) continue; // Ignore the row being edited

            if (availability.getHallName().equals(hallName) && availability.getDate().equals(date)) {
                // Check for overlap
                if ((startTime.compareTo(availability.getStartTime()) < 0 && endTime.compareTo(availability.getStartTime()) > 0) ||
                        (startTime.compareTo(availability.getEndTime()) < 0 && endTime.compareTo(availability.getEndTime()) > 0) ||
                        (startTime.equals(availability.getStartTime()) || endTime.equals(availability.getEndTime()))) {
                    return false; // Time overlaps
                }
            }
        }
        return true; // Time is available
    }

    private void loadAvailabilityData() {
        tableModel.setRowCount(0); // Clear the table
        for (Availability availability : DataIO.allAvailability) {
            tableModel.addRow(new Object[]{
                false, // Default value for the checkbox (unchecked)
                availability.getHallType(),
                availability.getHallName(),
                availability.getCapacity(),
                availability.getRatePerHour(),
                availability.getDate(),
                availability.getStartTime(),
                availability.getEndTime(),
                availability.getStatus(),
                availability.getPrice()
            });
        }
    }

    private ArrayList<Integer> getSelectedRows() {
        ArrayList<Integer> selectedRows = new ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean isSelected = (Boolean) tableModel.getValueAt(i, 0);
            if (isSelected != null && isSelected) {
                selectedRows.add(i);
            }
        }
        return selectedRows;
    }

    private Double calculatePrice(double ratePerHour, String startTime, String endTime, String status) {
        if ("Under Maintenance".equals(status)) {
            return null; // Return null for unavailable halls
        }

        try {
            int startHour = Integer.parseInt(startTime.split(":")[0]);
            int endHour = Integer.parseInt(endTime.split(":")[0]);
            int duration = endHour - startHour;
            return duration * ratePerHour;
        } catch (Exception e) {
            return 0.0; // Return default value on error
        }
    }
}
