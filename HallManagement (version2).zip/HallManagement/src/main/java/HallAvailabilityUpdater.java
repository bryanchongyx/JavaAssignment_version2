import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class HallAvailabilityUpdater {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static void updateAvailability() {
        LocalDate today = LocalDate.now();

        for (Availability availability : DataIO.allAvailability) {
            LocalDate availabilityDate;
            try {
                availabilityDate = LocalDate.parse(availability.getDate(), formatter);
            } catch (DateTimeParseException e) {
                System.err.println("Date format error: " + availability.getDate());
                continue; // Skip this entry if there's a parsing error
            }

            if (availabilityDate.isBefore(today)) {
                boolean isBooked = checkIfBooked(availability);
                if (!isBooked) {
                    availability.setStatus("Closed");
                }
            }
        }
        DataIO.write(); // Save changes to the file
    }

    private static boolean checkIfBooked(Availability availability) {
        // Check if there are any bookings for this availability
        for (Booking booking : DataIO.allBooking) {
            if (booking.getHallName().equals(availability.getHallName()) &&
                booking.getDate().equals(availability.getDate())) {
                return true; // Found a booking
            }
        }
        return false; // No bookings found
    }
}
