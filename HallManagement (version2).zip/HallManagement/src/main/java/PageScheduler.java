import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PageScheduler implements ActionListener {
    JFrame a;
    JButton management, scheduling, logout;
    Scheduler scheduler;

    public PageScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
        a = new JFrame("Scheduler Dashboard");
        a.setSize(400, 350);
        a.setLocationRelativeTo(null);
        a.setLayout(new GridBagLayout());
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.getContentPane().setBackground(new Color(240, 240, 240)); // Light background color
        

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        management = new JButton("Hall Management");
        scheduling = new JButton("Hall Scheduling");
        logout = new JButton("Logout");

        management.setBackground(new Color(100, 149, 237)); // Cornflower Blue
        scheduling.setBackground(new Color(60, 179, 113)); // Medium Sea Green
        logout.setBackground(new Color(255, 69, 0)); // Red-Orange

        management.setForeground(Color.WHITE);
        scheduling.setForeground(Color.WHITE);
        logout.setForeground(Color.WHITE);

        // Setting custom font
        Font font = new Font("Arial", Font.BOLD, 16);
        management.setFont(font);
        scheduling.setFont(font);
        logout.setFont(font);

        gbc.gridx = 0;
        gbc.gridy = 0;
        a.add(management, gbc);

        gbc.gridy = 1;
        a.add(scheduling, gbc);

        gbc.gridy = 2;
        a.add(logout, gbc);

        management.addActionListener(this);
        scheduling.addActionListener(this);
        logout.addActionListener(this);
    }

    public void showPage() {
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == management) {
            a.setVisible(false);
            if (Main.a11 == null) {
                Main.a11 = new PageHallManagement(this);
            }
            Main.a11.showPage();
        } else if (e.getSource() == scheduling) {
            a.setVisible(false);
            if (Main.a12 == null) {
                Main.a12 = new PageHallScheduling(this);
            }
            Main.a12.showPage();
        } else if (e.getSource() == logout) {
            a.setVisible(false);
            Main.a1.a.setVisible(true);
        }
    }
}
