import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Properties;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;
import org.jdatepicker.DateLabelFormatter;
import org.jdatepicker.impl.JDatePanelImpl;


public class PageHallBooking implements ActionListener {
    JFrame a;
    JTable availabilityTable;
    DefaultTableModel tableModel;
    JComboBox<String> hallTypeDropdown, hallDropdown;
    JButton bookButton, backButton;
    Customer customer; // Assuming a Customer class exists
    PageCustomer customerPage;
    JDatePickerImpl datePicker; 

    public PageHallBooking(Customer customer, PageCustomer customerPage) {
        this.customer = customer;
        this.customerPage = customerPage;
        a = new JFrame("Hall Booking");
        a.setSize(800, 600);
        a.setLayout(new BorderLayout());
        a.setLocationRelativeTo(null);

        // Table for displaying availability
        String[] columns = {"Select", "Hall Type", "Hall Name", "Capacity", "Rate Per Hour (RM)", "Date", "Start Time", "End Time", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Boolean.class; // Checkbox column
                }
                return super.getColumnClass(columnIndex);
            }
        };
        availabilityTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(availabilityTable);
        a.add(scrollPane, BorderLayout.CENTER);

        // Dropdowns for selecting hall type and date
        hallTypeDropdown = new JComboBox<>(new String[]{"All", "Auditorium", "Banquet Hall", "Meeting Room"});
        hallTypeDropdown.addActionListener(this);
        
        hallDropdown = new JComboBox<>();
        hallDropdown.setModel(new DefaultComboBoxModel<>(new String[]{"All"})); // Initialize with "All"
        
        // Date Picker
        UtilDateModel model = new UtilDateModel();
        Properties properties = new Properties();
        properties.put("text.today", "Today");
        properties.put("text.month", "Month");
        properties.put("text.year", "Year");
        datePicker = new JDatePickerImpl(new JDatePanelImpl(model, properties), new DateLabelFormatter());

        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(new JLabel("Select Hall Type:"));
        inputPanel.add(hallTypeDropdown);
        inputPanel.add(new JLabel("Select Hall:"));
        inputPanel.add(hallDropdown);
        inputPanel.add(new JLabel("Select Date:"));
        inputPanel.add(datePicker); // Use datePicker here
        a.add(inputPanel, BorderLayout.NORTH);
        

        JPanel buttonPanel = new JPanel();
        bookButton = new JButton("Book");
        bookButton.addActionListener(this);
        backButton = new JButton("Back");
        backButton.addActionListener(this);
        
        buttonPanel.add(bookButton);
        buttonPanel.add(backButton);
        a.add(buttonPanel, BorderLayout.SOUTH);

        loadAvailabilityData(); // Load availability data into the table

        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public void showPage() {
        a.setVisible(true); // Make the frame visible
    }

    private void loadAvailabilityData() {
        tableModel.setRowCount(0); // Clear the table
        String selectedHallType = (String) hallTypeDropdown.getSelectedItem();
        String selectedHallName = (String) hallDropdown.getSelectedItem();
        String selectedDate = (String) datePicker.getJFormattedTextField().getText().trim();

        for (Availability availability : DataIO.allAvailability) {
            // Check if the hall is available and matches the selected filters
            if ("Available".equals(availability.getStatus()) &&
                (selectedHallType.equals("All") || availability.getHallType().equals(selectedHallType)) &&
                (selectedHallName.equals("All") || availability.getHallName().equals(selectedHallName)) &&
                (selectedDate.equals("All") || availability.getDate().equals(selectedDate))) {
                
                tableModel.addRow(new Object[]{
                    false, // Default value for the checkbox
                    availability.getHallType(),
                    availability.getHallName(),
                    availability.getCapacity(),
                    availability.getRatePerHour(),
                    availability.getDate(),
                    availability.getStartTime(),
                    availability.getEndTime(),
                    availability.getStatus(),
                });
            }
        }
    }
    
    private String generateBookingId() {
        int lastId = getLastBookingId();
        return "BKG" + (lastId + 1);
    }

    private int getLastBookingId() {
        int lastId = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader("booking.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Assuming booking.txt has each booking record in one line and bookingId is the first field
                String[] fields = line.split(",");
                if (fields.length > 0 && fields[0].startsWith("BKG")) {
                    String bookingId = fields[0].substring(3); // Remove "BKG" prefix
                    try {
                        int id = Integer.parseInt(bookingId);
                        if (id > lastId) {
                            lastId = id;
                        }
                    } catch (NumberFormatException e) {
                        // Skip any malformed booking IDs
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading booking file: " + e.getMessage());
        }
        return lastId;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == hallTypeDropdown) {
            // Update hall dropdown based on selected hall type
            hallDropdown.setModel(new DefaultComboBoxModel<>(getFilteredHallNames((String) hallTypeDropdown.getSelectedItem())));
            loadAvailabilityData(); // Reload availability data after hall type change
        } else if (e.getSource() == hallDropdown || e.getSource() == datePicker) {
            loadAvailabilityData(); // Reload availability data when hall or date is changed
        } else if (e.getSource() == bookButton) {
            ArrayList<Integer> selectedRows = getSelectedRows();
            if (selectedRows.isEmpty()) {
                JOptionPane.showMessageDialog(a, "Please select a hall to book.");
                return;
            } else if (selectedRows.size() > 1) {
                JOptionPane.showMessageDialog(a, "Please select only one hall to book.");
                return;
            }

            int selectedRow = selectedRows.get(0);
            String hallType = (String) tableModel.getValueAt(selectedRow, 1);
            String hallName = (String) tableModel.getValueAt(selectedRow, 2);
            int capacity = (int) tableModel.getValueAt(selectedRow, 3);
            double ratePerHour = (double) tableModel.getValueAt(selectedRow, 4);
            String date = (String) tableModel.getValueAt(selectedRow, 5);
            String startTime = (String) tableModel.getValueAt(selectedRow, 6);
            String endTime = (String) tableModel.getValueAt(selectedRow, 7);
            
            // Calculate the price based on rate per hour and hours booked
            double price = calculatePrice(ratePerHour, startTime, endTime);
            String bookingId = generateBookingId();

            // Create the Booking object
            Booking booking = new Booking(bookingId, customer.getUserid(), customer.getFullname(), customer.getPh_number(), customer.getEmail(),
                    hallType, hallName, capacity, ratePerHour, date, startTime, endTime, getCurrentDate(), price, "Booked");

            // Show receipt
            showReceipt(booking);
        } else if (e.getSource() == backButton) {
            a.setVisible(false);
            customerPage.a.setVisible(true);
        }
    }

    private ArrayList<Integer> getSelectedRows() {
        ArrayList<Integer> selectedRows = new ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean isSelected = (Boolean) tableModel.getValueAt(i, 0);
            if (isSelected != null && isSelected) {
                selectedRows.add(i);
            }
        }
        return selectedRows;
    }

    private void showReceipt(Booking booking) {
        JFrame receiptFrame = new JFrame("Receipt");
        receiptFrame.setSize(500, 500);
        receiptFrame.setLayout(new BorderLayout());
        receiptFrame.setLocationRelativeTo(null);

        // Create a panel for the receipt details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new GridLayout(0, 2, 10, 10)); // 2 columns with 10px padding
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding around the panel

        // Add receipt details
        detailsPanel.add(new JLabel("Customer Name:"));
        detailsPanel.add(new JLabel(booking.getFullname()));

        detailsPanel.add(new JLabel("User ID:"));
        detailsPanel.add(new JLabel(booking.getUserid()));

        detailsPanel.add(new JLabel("Phone Number:"));
        detailsPanel.add(new JLabel(booking.getPh_number()));

        detailsPanel.add(new JLabel("Email:"));
        detailsPanel.add(new JLabel(booking.getEmail()));

        detailsPanel.add(new JLabel("Hall Type:"));
        detailsPanel.add(new JLabel(booking.getHallType()));

        detailsPanel.add(new JLabel("Hall Name:"));
        detailsPanel.add(new JLabel(booking.getHallName()));

        detailsPanel.add(new JLabel("Capacity:"));
        detailsPanel.add(new JLabel(String.valueOf(booking.getCapacity())));

        detailsPanel.add(new JLabel("Rate Per Hour:"));
        detailsPanel.add(new JLabel("RM " + booking.getRatePerHour()));

        detailsPanel.add(new JLabel("Date:"));
        detailsPanel.add(new JLabel(booking.getDate()));

        detailsPanel.add(new JLabel("Start Time:"));
        detailsPanel.add(new JLabel(booking.getStartTime()));

        detailsPanel.add(new JLabel("End Time:"));
        detailsPanel.add(new JLabel(booking.getEndTime()));

        detailsPanel.add(new JLabel("Price:"));
        detailsPanel.add(new JLabel("RM " + booking.getPrice())); // Display the price

        detailsPanel.add(new JLabel("Booking Date:"));
        detailsPanel.add(new JLabel(getCurrentDate()));

        // Add the details panel to the center of the frame
        receiptFrame.add(detailsPanel, BorderLayout.CENTER);

        // Create and add a confirm button
        JButton confirmButton = new JButton("Confirm");
        JButton cancelButton = new JButton ("Cancel");
        
        confirmButton.addActionListener(e -> {
            updateAvailabilityStatus(booking); // Update availability status to "Booked"
            DataIO.allBooking.add(booking); // Save booking to booking.txt
            receiptFrame.dispose(); // Close receipt window
            DataIO.write();
            JOptionPane.showMessageDialog(a, "Booking confirmed!");
            loadAvailabilityData(); // Refresh the table data
        });
        
        cancelButton.addActionListener (e ->{
            receiptFrame.dispose();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(confirmButton);
        buttonPanel.add (cancelButton);
        receiptFrame.add(buttonPanel, BorderLayout.SOUTH); // Add button panel to the bottom

        receiptFrame.setVisible(true);
    }


    private String[] getFilteredHallNames(String hallType) {
        ArrayList<String> hallNames = new ArrayList<>();
        hallNames.add("All"); // Add "All" option
        for (Hall hall : DataIO.allHall) {
            if (hall.getHallType().equals(hallType) || hallType.equals("All")) {
                hallNames.add(hall.getHallName());
            }
        }
        return hallNames.toArray(new String[0]);
    }

    private String getCurrentDate() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return today.format(formatter);
    }

    // Calculate price based on rate per hour and duration
    private double calculatePrice(double ratePerHour, String startTime, String endTime) {
        try {
            int startHour = Integer.parseInt(startTime.split(":")[0]);
            int endHour = Integer.parseInt(endTime.split(":")[0]);
            int duration = endHour - startHour;
            return duration * ratePerHour;
        } catch (Exception e) {
            return 0.0; // Return default value on error
        }
    }
    
    public void updateAvailabilityStatus(Booking booking) {
        for (Availability availability : DataIO.allAvailability) {
            if (availability.getHallName().equals(booking.getHallName()) &&
                availability.getDate().equals(booking.getDate()) &&
                availability.getStartTime().equals(booking.getStartTime()) &&
                availability.getEndTime().equals(booking.getEndTime())) {
                    
                availability.setStatus("Booked");
                break; // Exit the loop once the correct entry is found and updated
            }
        }
    }
}
