import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class DataIO {
    public static ArrayList<User> allUser = new ArrayList<>();
    public static ArrayList<Customer> allCustomer = new ArrayList<>();
    public static ArrayList<Admin> allAdmin = new ArrayList<>();
    public static ArrayList<Scheduler> allScheduler = new ArrayList<>();
    public static ArrayList<Manager> allManager = new ArrayList<>();
    public static ArrayList <Hall> allHall = new ArrayList<>();
    public static ArrayList <Availability> allAvailability = new ArrayList<>();
    public static ArrayList <Booking> allBooking = new ArrayList<>();
    public static ArrayList <Issue> allIssue = new ArrayList<>();

    public static void read() {
        try {
            // Reading from user.txt
            Scanner a = new Scanner(new File("user.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] userData = line.split(",");
                if (userData.length == 4) { // Ensure there are 4 fields
                    String fullname = userData[0].trim();
                    String userid = userData[1].trim();
                    String password = userData[2].trim();
                    String roles = userData[3].trim();
                    allUser.add(new User(fullname, userid, password, roles));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }

            // Reading from customer.txt
            a = new Scanner(new File("customer.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] customerData = line.split(",");
                if (customerData.length == 5) {
                    String fullname = customerData[0].trim();
                    String userid = customerData[1].trim();
                    String password = customerData[2].trim();
                    String email = customerData[3].trim();
                    String ph_number = customerData[4].trim();
                    allCustomer.add(new Customer(fullname, userid, password, email, ph_number));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }

            // Reading from admin.txt
            a = new Scanner(new File("admin.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] adminData = line.split(",");
                if (adminData.length == 4) {
                    String fullname = adminData[0].trim();
                    String userid = adminData[1].trim();
                    String password = adminData[2].trim();
                    String joinedDate = adminData[3].trim();
                    allAdmin.add(new Admin(fullname, userid, password, joinedDate));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }

            // Reading from scheduler.txt
            a = new Scanner(new File("scheduler.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] schedulerData = line.split(",");
                if (schedulerData.length == 4) {
                    String fullname = schedulerData[0].trim();
                    String userid = schedulerData[1].trim();
                    String password = schedulerData[2].trim();
                    String joinedDate = schedulerData[3].trim();
                    allScheduler.add(new Scheduler(fullname, userid, password, joinedDate));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }

            // Reading from manager.txt
            a = new Scanner(new File("manager.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] managerData = line.split(",");
                if (managerData.length == 4) {
                    String fullname = managerData[0].trim();
                    String userid = managerData[1].trim();
                    String password = managerData[2].trim();
                    String joinedDate = managerData[3].trim();
                    allManager.add(new Manager(fullname, userid, password, joinedDate));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }
            
            a = new Scanner (new File ("hall.txt"));
            while (a.hasNextLine()){
                String line = a.nextLine();
                String [] hallData = line.split (",");
                if (hallData.length ==4){
                    String hallName = hallData[0].trim();
                    String hallType = hallData[1].trim ();
                    int capacity = Integer.parseInt(hallData[2].trim());
                    double ratePerHour = Double.parseDouble(hallData[3].trim());
                    allHall.add (new Hall (hallName, hallType, capacity, ratePerHour));
                }else{
                    System.out.println ("Invalid line format: "+ line);
                }
            }
            
            a = new Scanner (new File ("availability.txt"));
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] availabilityData = line.split(",");
                if (availabilityData.length == 9) { // Update to 8 for new fields
                    String hallType = availabilityData[0].trim();
                    String hallName = availabilityData[1].trim();
                    int capacity = Integer.parseInt(availabilityData[2].trim());
                    double ratePerHour = Double.parseDouble(availabilityData[3].trim());
                    String date = availabilityData[4].trim();
                    String startTime = availabilityData[5].trim();
                    String endTime = availabilityData[6].trim();
                    String status = availabilityData[7].trim();
                    double price = Double.parseDouble(availabilityData[8].trim()); // Correct parsing
                    
                    allAvailability.add(new Availability(hallType, hallName, capacity, ratePerHour, date, startTime, endTime, status, price));
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }
            a = new Scanner (new File ("booking.txt"));    
            while (a.hasNextLine()) {
                String line = a.nextLine();
                String[] bookingData = line.split(",");
                if (bookingData.length == 15) { // Use '==' for comparison
                    String bookingId = bookingData[0].trim();
                    String userid = bookingData[1].trim();
                    String fullname = bookingData[2].trim();
                    String ph_number = bookingData[3].trim(); // Correctly capture phone number
                    String email = bookingData[4].trim();
                    String hallType = bookingData[5].trim();
                    String hallName = bookingData[6].trim();
                    int capacity = Integer.parseInt(bookingData[7].trim()); // Parse capacity
                    double ratePerHour = Double.parseDouble(bookingData[8].trim()); // Parse ratePerHour
                    String date = bookingData[9].trim();
                    String startTime = bookingData[10].trim();
                    String endTime = bookingData[11].trim();
                    String bookedDate = bookingData[12].trim();
                    double price = Double.parseDouble(bookingData[13].trim()); // Correct parsing
                    String status = bookingData[14].trim();

                    allBooking.add (new Booking(bookingId,userid, fullname, ph_number, email, hallType, hallName, capacity, ratePerHour, date, startTime, endTime, bookedDate, price, status));

                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }
            a = new Scanner (new File ("issue.txt"));
            while (a.hasNextLine()){
                String line = a.nextLine();
                String[] issueData = line.split(",");
                if (issueData.length == 5){
                    String bookingId = issueData[0].trim();
                    String hallName = issueData[1].trim();
                    String userid = issueData[2].trim();
                    String issueDescription = issueData[3].trim();
                    String dateReported = issueData[4].trim();
                    
                    allIssue. add (new Issue (bookingId, hallName, userid, issueDescription, dateReported));
                }else {
                    System.out.println("Invalid line format: " + line);
                }
            }

            a.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error reading files.");
        }
    }

    // Check if a username already exists in allUser
    public static User checkUserid(String s) {
        for (User u : allUser) {
            if (s.equals(u.getUserid())) {
                return u;
            }
        }
        return null;
    }

    // Check the role of a user by username
    public static String checkUserRole(String userid) {
        for (User u : allUser) {
            if (userid.equals(u.getUserid())) {
                return u.getRoles();
            }
        }
        return null;
    }

    // Check if a customer username already exists
    public static Customer checkCustomerUserid(String s) {
        for (Customer c : allCustomer) {
            if (s.equals(c.getUserid())) {
                return c;
            }
        }
        return null;
    }

    // Check if a customer email is already registered
    public static Customer checkCustomerEmail(String s) {
        for (Customer c : allCustomer) {
            if (s.equals(c.getEmail())) {
                return c;
            }
        }
        return null;
    }

    // Check if a customer phone number is already registered
    public static Customer checkCustomerPhone(String phone) {
        for (Customer c : allCustomer) {
            if (c.getPh_number().equals(phone)) {
                return c;
            }
        }
        return null;
    }

    // Check if an admin username already exists
    public static Admin checkAdminUserid(String s) {
        for (Admin admin : allAdmin) {
            if (s.equals(admin.getUserid())) {
                return admin;
            }
        }
        return null;
    }

    // Check if a scheduler username already exists
    public static Scheduler checkSchedulerUserid(String username) {
        for (Scheduler scheduler : allScheduler) {
            if (username.equals(scheduler.getUserid())) {
                return scheduler;
            }
        }
        return null;
    }
    
    //Find superadmin by User ID
    public static User findSuperAdminByUserid(String userid) {
        for (User user : allUser) { // Assuming allUser is a List<User> containing all users
            if (user.getUserid().equals(userid) && user.getRoles().equals ("superadmin")) {
                return (User) user; // Cast the User to SuperAdmin
            }
        }
        return null; // Return null if no matching SuperAdmin is found
    }

    // Find an admin by user ID
    public static Admin findAdminByUserId(String userid) {
        for (Admin admin : allAdmin) {
            if (admin.getUserid().equals(userid)) {
                return admin;
            }
        }
        return null;
    }

    // Find a scheduler by username
    public static Scheduler findSchedulerByUserid(String userid) {
        for (Scheduler scheduler : allScheduler) {
            if (scheduler.getUserid().equals(userid)) {
                return scheduler;
            }
        }
        return null;
    }

    // Find a manager by username
    public static Manager findManagerByUserid(String userid) {
        for (Manager manager : allManager) {
            if (manager.getUserid().equals(userid)) {
                return manager;
            }
        }
        return null;
    }
    
    public static Customer findCustomerByUserid (String userid){
        for (Customer customer: allCustomer){
        if (customer.getUserid().equals (userid)){
            return customer;
            }
        }
        return null;
    }
    
    public static Hall findHallByName(String hallName) {
        for (Hall hall : allHall) {
            if (hall.getHallName().equals(hallName)) {
                return hall;
            }
        }
        return null;
    }

    // Remove a user by user ID
    public static void removeUserByUserId(String userid) {
        allUser.removeIf(user -> user.getUserid().equals(userid));
    }

    
    //Remove hall by username
    public static void removeHallByHallname (String hallName){
        allHall.removeIf(hall -> hall.getHallName().equals (hallName));
    }

    // Update User UserID
    public static void updateUserUserid(String oldUserid, String newUserid) {
        for (User user : allUser) {
            if (user.getUserid().equals(oldUserid)) {
                user.setUserid(newUserid);
                break;
            }
        }
    }

    // Update Scheduler UserID
    public static void updateSchedulerUserid(String oldUserid, String newUserid) {
        for (Scheduler scheduler : allScheduler) {
            if (scheduler.getUserid().equals(oldUserid)) {
                scheduler.setUserid(newUserid);
                break;
            }
        }
        updateUserUserid(oldUserid, newUserid); // Update in users list
    }

    // Update Manager UserID
    public static void updateManagerUserid(String oldUserid, String newUserid) {
        for (Manager manager : allManager) {
            if (manager.getUserid().equals(oldUserid)) {
                manager.setUserid(newUserid);
                break;
            }
        }
        updateUserUserid(oldUserid, newUserid); // Update in users list
    }
    
    //Update Admin UserID
    public static void updateAdminUserid(String oldUserid, String newUserid) {
        for (Admin admin : allAdmin) {
            if (admin.getUserid().equals(oldUserid)) {
                admin.setUserid(newUserid);
                break;
            }
        }
        updateUserUserid (oldUserid, newUserid); //Update in users list
    }
    
    //Update 
    public static void updateCustomerUserid(String oldUserid, String newUserid) {
        for (Customer customer : allCustomer) {
            if (customer.getUserid().equals(oldUserid)) {
                customer.setUserid(newUserid);
                break;
            }
        }
        updateUserUserid (oldUserid, newUserid); //Update in users list
    }
    
    
    // Update User Fullname
    public static void updateUserFullname(String oldUserid, String newFullname) {
        for (User user : allUser) {
            if (user.getUserid().equals(oldUserid)) {
                user.setFullname(newFullname);
                break;
            }
        }
    }

    // Update Scheduler Fullname
    public static void updateSchedulerFullname(String userid, String newFullname) {
        for (Scheduler scheduler : allScheduler) {
            if (scheduler.getUserid().equals(userid)) {
                scheduler.setFullname(newFullname);
                break;
            }
        }
        updateUserFullname(userid, newFullname); // Update in users list
    }

    // Update Manager Fullname
    public static void updateManagerFullname(String userid, String newFullname) {
        for (Manager manager : allManager) {
            if (manager.getUserid().equals(userid)) {
                manager.setFullname(newFullname);
                break;
            }
        }
        updateUserFullname(userid, newFullname); // Update in users list
    }

    // Update Admin Fullname
    public static void updateAdminFullname(String userid, String newFullname) {
        for (Admin admin : allAdmin) {
            if (admin.getUserid().equals(userid)) {
                admin.setFullname(newFullname);
                break;
            }
        }
        updateUserFullname(userid, newFullname); // Update in users list
    }
    
    //Update Customer Fullname
    public static void updateCustomerFullname (String userid, String newFullname){
        for (Customer customer : allCustomer){
            if (customer.getUserid().equals (userid)){
                customer.setFullname (newFullname);
                break;
            }
        }
        updateUserFullname(userid, newFullname);
    }

    // Update User Password
    public static void updateUserPassword(String userid, String newPassword) {
        for (User user : allUser) {
            if (user.getUserid().equals(userid)) {
                user.setPassword(newPassword);
                break;
            }
        }
    }

    // Update Scheduler Password
    public static void updateSchedulerPassword(String userid, String newPassword) {
        for (Scheduler scheduler : allScheduler) {
            if (scheduler.getUserid().equals(userid)) {
                scheduler.setPassword(newPassword);
                break;
            }
        }
        updateUserPassword(userid, newPassword); // Update in users list
    }

    // Update Manager Password
    public static void updateManagerPassword(String userid, String newPassword) {
        for (Manager manager : allManager) {
            if (manager.getUserid().equals(userid)) {
                manager.setPassword(newPassword);
                break;
            }
        }
        updateUserPassword(userid, newPassword); // Update in users list
    }

    // Update Admin Password
    public static void updateAdminPassword(String userid, String newPassword) {
        for (Admin admin : allAdmin) {
            if (admin.getUserid().equals(userid)) {
                admin.setPassword(newPassword);
                break;
            }
        }
        updateUserPassword(userid, newPassword); // Update in users list
    }
    
    //Update Customer Password
    public static void updateCustomerPassword(String userid, String newPassword) {
        for (Customer customer : allCustomer) {
            if (customer.getUserid().equals(userid)) {
                customer.setPassword(newPassword);
                break;
            }
        }
        updateUserPassword(userid, newPassword); // Update in users list
    }
    
    //Update Customer Email
    public static void updateCustomerEmail (String userid, String newEmail){
        for (Customer customer: allCustomer){
            if (customer.getUserid().equals (userid)){
                customer.setEmail (newEmail);
                break;
            }
        }
    }
    
    public static void updateCustomerPhNumber (String userid, String newPhNumber){
        for (Customer customer: allCustomer){
            if (customer.getUserid().equals (userid)){
                customer.setPh_number (newPhNumber);
                break;
            }
        }
    }
    
    //Update Hall Name
    public static void updateHallName (String hallName, String newHallName){
        for (Hall hall: allHall){
            if (hall.getHallName().equals (hallName)){
                hall.setHallName(newHallName);
                break;
            }
        }
    }
    
    public static void updateAvailabilityHallName(String oldHallName, String newHallName) {
    for (Availability availability : allAvailability) {
        if (availability.getHallName().equals(oldHallName)) {
            availability.setHallName(newHallName);
        }
    }
        DataIO.write(); // Save the changes to the availability file
    }
    
    //public static void updateHallAvailability 
    
    public static int getHallCapacity(String hallName) {
        for (Hall hall : allHall) {
            if (hall.getHallName().equals(hallName)) {
                return hall.getCapacity();
            }
        }
        return 0; // Default value if hall not found
    }

    public static double getHallRate(String hallName) {
        for (Hall hall : allHall) {
            if (hall.getHallName().equals(hallName)) {
                return hall.getRatePerHour();
            }
        }
        return 0.0; // Default value if hall not found
    }



    public static void write() {
        try {
            PrintWriter a;

            // Writing to user.txt
            a = new PrintWriter("user.txt");
            for (User u : allUser) {
                a.println(u.getFullname() + "," + u.getUserid() + "," + u.getPassword() + "," + u.getRoles());
            }
            a.close();

            // Writing to customer.txt
            a = new PrintWriter("customer.txt");
            for (Customer c : allCustomer) {
                a.println(c.getFullname() + "," + c.getUserid() + "," + c.getPassword() + "," + c.getEmail() + "," + c.getPh_number());
            }
            a.close();

            // Writing to admin.txt
            a = new PrintWriter("admin.txt");
            for (Admin admin : allAdmin) {
                a.println(admin.getFullname() + "," + admin.getUserid() + "," + admin.getPassword() + "," + admin.getDate());
            }
            a.close();

            // Writing to scheduler.txt
            a = new PrintWriter("scheduler.txt");
            for (Scheduler scheduler : allScheduler) {
                a.println(scheduler.getFullname() + "," + scheduler.getUserid() + "," + scheduler.getPassword() + "," + scheduler.getJoinedDate());
            }
            a.close();

            // Writing to manager.txt
            a = new PrintWriter("manager.txt");
            for (Manager manager : allManager) {
                a.println(manager.getFullname() + "," + manager.getUserid() + "," + manager.getPassword() + "," + manager.getJoinedDate());
            }
            a.close();
            
            a = new PrintWriter ("hall.txt");
            for (Hall hall : allHall) {
                a.println(hall.getHallName() + "," + hall.getHallType() + "," + hall.getCapacity() + "," + hall.getRatePerHour());
            }
            a.close();
            
            a = new PrintWriter ("availability.txt");
            for (Availability availability: allAvailability){
                a.println (availability.getHallType() + "," + availability.getHallName() + "," + availability.getCapacity() + "," 
                        + availability.getRatePerHour() + "," + availability.getDate() + "," + availability.getStartTime() + "," +
                        availability.getEndTime() + "," + availability.getStatus() + "," + availability.getPrice());
            }
            a.close();
            
            a= new PrintWriter ("booking.txt");
            for (Booking booking : allBooking){
                a.println (booking.getBookingId() + "," +booking.getUserid() + "," + booking.getFullname() + "," + booking.getPh_number() + "," + 
                        booking.getEmail() + "," + booking.getHallType() + "," +  booking.getHallName() + "," + 
                        booking.getCapacity()  + "," + booking.getRatePerHour() + "," +  booking.getDate()   + "," + 
                        booking.getStartTime()  + "," +  booking.getEndTime()  + "," + booking.getBookedDate()  + "," + 
                        booking.getPrice() + "," + booking.getStatus());
            }
            a.close();
            
            a = new PrintWriter ("issue.txt");
            for (Issue issue : allIssue){
                a.println (issue.getBookingId() + "," + issue.getHallName() + "," + issue.getUserid() + "," + issue.getIssueDescription()
                 + "," + issue.getDateReported());
            }
            a.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error writing to files.");
        }
    }


}
