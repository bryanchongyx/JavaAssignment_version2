import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PageSuperAdmin implements ActionListener {
    JFrame a;
    JButton manage, edit, logout;
    User user;
    
    public PageSuperAdmin(User user) {
        this.user = user;
        a = new JFrame();
        a.setTitle("Super Admin Dashboard");
        a.setSize(500, 400);
        a.setLocationRelativeTo(null); // Center the frame on screen
        a.setLayout(new GridBagLayout()); // Use GridBagLayout for better alignment
        
        // Components
        manage = new JButton("Manage Admin");
        edit = new JButton("Edit Profile");
        logout = new JButton("Logout");
        
        
        manage.addActionListener(this);
        edit.addActionListener(this);
        logout.addActionListener(this);
        
        // GridBagConstraints for layout control
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Add components with constraints
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        
        JLabel title = new JLabel("Super Admin Dashboard");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        a.add(title, gbc);
        
        gbc.gridy++;
        gbc.gridwidth = 1;
        a.add(manage, gbc);
        
        gbc.gridx++;
        a.add(edit, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        a.add(logout, gbc);
        
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == manage) {
                a.setVisible(false);
                if (Main.a9 == null) {
                    Main.a9 = new PageAdminManagement(this);
                }
                Main.a9.showPage();
            } else if (e.getSource() == edit) {
                try {
                    // Prompt for new full name
                    String newFullname = JOptionPane.showInputDialog(a, "Edit Full Name:", user.getFullname());
                    if (newFullname == null || newFullname.trim().isEmpty()) {
                        throw new Exception("Full Name cannot be empty!");
                    }
                    user.setFullname(newFullname.trim());
                    DataIO.updateUserFullname(user.getUserid(), newFullname.trim());

                    // Prompt for new user ID
                    String newUserid = JOptionPane.showInputDialog(a, "Edit User ID:", user.getUserid());
                    if (newUserid == null || newUserid.trim().isEmpty()) {
                        throw new Exception("User ID cannot be empty!");
                    }
                    if (!newUserid.equals(user.getUserid()) && DataIO.checkUserid(newUserid.trim()) != null) {
                        throw new Exception("User ID is already taken!");
                    }
                    user.setUserid(newUserid.trim());
                    DataIO.updateUserUserid(user.getUserid(), newUserid.trim());

                    // Prompt for new password
                    String newPassword = JOptionPane.showInputDialog(a, "Edit Password:", user.getPassword());
                    if (newPassword == null || newPassword.trim().isEmpty()) {
                        throw new Exception("Password cannot be empty!");
                    }
                    user.setPassword(newPassword.trim());
                    DataIO.updateUserPassword(user.getUserid(), newPassword.trim());

                    // Save data
                    DataIO.write();
                    JOptionPane.showMessageDialog(a, "Super Admin details updated successfully.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(a, "Failed to update Super Admin details: " + ex.getMessage());
                }


            } else if (e.getSource() == logout) {
                a.setVisible(false);
                Main.a1.a.setVisible(true);
            }
        } catch (Exception ex) {
            // Display error message with details
            JOptionPane.showMessageDialog(a, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
