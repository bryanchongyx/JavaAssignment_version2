public class Issue {
    private String bookingId;
    private String hallName;
    private String userid;
    private String issueDescription;
    private String dateReported;

    public Issue(String bookingId, String hallName, String userid, String issueDescription, String dateReported) {
        this.bookingId = bookingId;
        this.hallName = hallName;
        this.userid = userid;
        this.issueDescription = issueDescription;
        this.dateReported = dateReported;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getDateReported() {
        return dateReported;
    }

    public void setDateReported(String dateReported) {
        this.dateReported = dateReported;
    }

    
}
