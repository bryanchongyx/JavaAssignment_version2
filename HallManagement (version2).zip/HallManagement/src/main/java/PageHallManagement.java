import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;

public class PageHallManagement implements ActionListener {
    JFrame a;
    JTable hallTable;
    DefaultTableModel tableModel;
    JTextField filterField;
    TableRowSorter<DefaultTableModel> rowSorter;
    JButton addButton, editButton, deleteButton, backButton;
    PageScheduler schedulerPage;

    public PageHallManagement(PageScheduler schedulerPage) {
        this.schedulerPage = schedulerPage;
        a = new JFrame("Hall Management");
        a.setSize(900, 500);
        a.setLayout(new BorderLayout());
        a.setLocationRelativeTo(null);

        // Table model with Select column
        String[] columns = {"Select", "Name", "Type", "Capacity", "Rate Per Hour (RM)"};
        tableModel = new DefaultTableModel(columns, 0);
        hallTable = new JTable(tableModel) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 0 ? Boolean.class : String.class; // Checkbox for 'Select' column
            }
        };
        rowSorter = new TableRowSorter<>(tableModel);
        hallTable.setRowSorter(rowSorter);

        // Load data into the table
        loadHallData();

        // Scroll pane for the table
        JScrollPane scrollPane = new JScrollPane(hallTable);
        a.add(scrollPane, BorderLayout.CENTER);

        // Search bar
        filterField = new JTextField(15);
        filterField.addActionListener(this);
        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(filterField);
        a.add(searchPanel, BorderLayout.NORTH);

        filterField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String text = filterField.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    // Custom RowFilter to search across all columns
                    rowSorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
                        @Override
                        public boolean include(RowFilter.Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                            for (int i = 0; i < entry.getValueCount(); i++) {
                                // Check if any column contains the filter text
                                if (entry.getStringValue(i).toLowerCase().contains(text.toLowerCase())) {
                                    return true; // If found, include this row
                                }
                            }
                            return false; // If not found, exclude this row
                        }
                    });
                }
            }
        });

        // Button panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        backButton = new JButton("Back");

        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        backButton.addActionListener(this);

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);
        a.add(buttonPanel, BorderLayout.SOUTH);

        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void showPage() {
        a.setVisible(true); // Make the frame visible
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == addButton) {
                String hallName = JOptionPane.showInputDialog(a, "Enter Hall Name:");
                if (DataIO.findHallByName(hallName) != null) {
                    throw new Exception("Hall name is taken");
                }
                if (hallName == null || hallName.trim().isEmpty()) return;

                String[] hallTypes = {"Auditorium", "Banquet Hall", "Meeting Room"};
                String hallType = (String) JOptionPane.showInputDialog(a, "Select Hall Type:",
                        "Hall Type", JOptionPane.QUESTION_MESSAGE, null, hallTypes, hallTypes[0]);
                if (hallType == null) return;

                int capacity = 0;
                double ratePerHour = 0.0;

                switch (hallType) {
                    case "Auditorium":
                        capacity = 1000;
                        ratePerHour = 300.0;
                        break;
                    case "Banquet Hall":
                        capacity = 300;
                        ratePerHour = 100.0;
                        break;
                    case "Meeting Room":
                        capacity = 30;
                        ratePerHour = 50.0;
                        break;
                }

                DataIO.allHall.add(new Hall(hallName, hallType, capacity, ratePerHour));
                DataIO.write();
                JOptionPane.showMessageDialog(a, "Hall Added Successfully");
                loadHallData();

            } else if (e.getSource() == editButton) {
                ArrayList<Integer> selectedRows = getSelectedRows();
                if (selectedRows.size() != 1) {
                    JOptionPane.showMessageDialog(a, "Please select exactly one hall to edit.");
                    return;
                }

                int selectedRow = selectedRows.get(0);
                String currentHallName = (String) hallTable.getValueAt(selectedRow, 1);
                Hall hallToEdit = DataIO.findHallByName(currentHallName);

                // Check if the hall has associated availability
                if (hasAvailability(currentHallName)) {
                    JOptionPane.showMessageDialog(a, "Cannot edit hall " + currentHallName + " because it is associated with availability.");
                    return;
                }

                if (hallToEdit != null) {
                    String newHallName = JOptionPane.showInputDialog(a, "Enter new Hall Name:", hallToEdit.getHallName());

                    // Check if new hall name already exists
                    if (DataIO.findHallByName(newHallName) != null) {
                        throw new Exception("Hall name is taken");
                    }

                    // Proceed with the update if the new name is valid
                    if (newHallName != null && !newHallName.trim().isEmpty()) {
                        hallToEdit.setHallName(newHallName);
                        DataIO.updateHallName(currentHallName, newHallName);
                        DataIO.updateAvailabilityHallName(currentHallName, newHallName); // Update availability
                        DataIO.write(); // Write to hall.txt
                        JOptionPane.showMessageDialog(a, "Hall information updated successfully");
                        loadHallData();
                    }
                }

            } else if (e.getSource() == deleteButton) {
                // Delete selected hall
                ArrayList<Hall> hallsToDelete = new ArrayList<>();
                for (int i = 0; i < hallTable.getRowCount(); i++) {
                    boolean isSelected = (boolean) hallTable.getValueAt(i, 0);
                    if (isSelected) {
                        String hallName = (String) hallTable.getValueAt(i, 1);
                        if (hasAvailability(hallName)) {
                            JOptionPane.showMessageDialog(a, "Cannot delete hall " + hallName + " because it has associated availability.");
                            return;
                        }
                        hallsToDelete.add(DataIO.findHallByName(hallName));
                    }
                }
                if (hallsToDelete.isEmpty()) {
                    JOptionPane.showMessageDialog(a, "No halls selected for deletion");
                } else {
                    // Remove selected halls from the list and update the file
                    for (Hall hall : hallsToDelete) {
                        DataIO.allHall.remove(hall);
                        DataIO.removeHallByHallname(hall.getHallName());
                    }
                    DataIO.write();
                    loadHallData();
                    JOptionPane.showMessageDialog(a, "Selected halls deleted successfully.");
                }

            } else if (e.getSource() == backButton) {
                a.setVisible(false);
                schedulerPage.a.setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(a, ex.getMessage());
        }
    }

    // Method to load hall data into the table
    private void loadHallData() {
        tableModel.setRowCount(0); // Clear the table
        for (Hall hall : DataIO.allHall) {
            Object[] row = {false, hall.getHallName(), hall.getHallType(), hall.getCapacity(),
                    hall.getRatePerHour()};
            tableModel.addRow(row);
        }
    }

    // Method to get selected rows
    private ArrayList<Integer> getSelectedRows() {
        ArrayList<Integer> selectedRows = new ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean isSelected = (Boolean) tableModel.getValueAt(i, 0);
            if (isSelected != null && isSelected) {
                selectedRows.add(i);
            }
        }
        return selectedRows;
    }

    // Method to check if a hall has any availability
    private boolean hasAvailability(String hallName) {
        for (Availability availability : DataIO.allAvailability) {
            if (availability.getHallName().equals(hallName)) {
                return true;
            }
        }
        return false;
    }
}
