import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class PageBookingManagement implements ActionListener {
    JFrame a;
    JTable bookingTable;
    DefaultTableModel tableModel;
    JComboBox<String> filterDropdown, issueDropdown;
    JButton cancelBookingButton, raiseIssueButton, backButton;
    Customer customer; // Current logged-in customer
    String[] availableIssues = {"Lights problem", "Airconditioning issues", "Sound issues", "Seating problem"};
    PageCustomer customerPage;

    public PageBookingManagement(Customer customer, PageCustomer customerPage) {
        this.customer = customer;
        this.customerPage = customerPage;
        a = new JFrame("Booking Management");
        a.setSize(900, 600);
        a.setLayout(new BorderLayout());
        a.setLocationRelativeTo(null);

        // Table for displaying bookings
        String[] columns = {"Select", "Booking ID", "Hall Type", "Hall Name", "Date", "Start Time", "End Time", "Status", "Price"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Boolean.class; // Set the first column to Boolean class
                }
                return super.getColumnClass(columnIndex);
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0; // Only the select column is editable
            }
        };
        bookingTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        a.add(scrollPane, BorderLayout.CENTER);

        // Panel for filter and buttons
        JPanel actionPanel = new JPanel(new FlowLayout());

        // Filter Dropdown for past/upcoming bookings
        filterDropdown = new JComboBox<>(new String[]{"All Bookings", "Past Bookings", "Upcoming Bookings"});
        filterDropdown.addActionListener(this);
        actionPanel.add(new JLabel("Filter:"));
        actionPanel.add(filterDropdown);

        // Cancel Booking Button
        cancelBookingButton = new JButton("Cancel Booking");
        cancelBookingButton.addActionListener(this);
        actionPanel.add(cancelBookingButton);
        
        //Back Button
        backButton = new JButton ("Back");
        backButton.addActionListener (this);
        actionPanel.add (backButton);

        // Issue Dropdown
        issueDropdown = new JComboBox<>(availableIssues);
        raiseIssueButton = new JButton("Raise Issue");
        raiseIssueButton.addActionListener(this);
        actionPanel.add(issueDropdown);
        actionPanel.add(raiseIssueButton);
        actionPanel.add (backButton);

        a.add(actionPanel, BorderLayout.SOUTH);
        loadBookings(); // Load bookings into the table

        a.setVisible(true);
        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void loadBookings() {
        tableModel.setRowCount(0); // Clear existing rows
        for (Booking booking : DataIO.allBooking) {
            if (booking.getUserid().equals(customer.getUserid())) { // Filter by customer
                tableModel.addRow(new Object[]{
                        false, // Default checkbox state
                        booking.getBookingId(),
                        booking.getHallType(),
                        booking.getHallName(),
                        booking.getDate(),
                        booking.getStartTime(),
                        booking.getEndTime(),
                        booking.getStatus(),
                        booking.getPrice()
                });
            }
        }
    }

    private void filterBookings() {
        String filter = (String) filterDropdown.getSelectedItem();
        tableModel.setRowCount(0); // Clear existing rows

        for (Booking booking : DataIO.allBooking) {
            if (booking.getUserid().equals(customer.getUserid())) { // Filter by customer
                LocalDate bookingDate = LocalDate.parse(booking.getDate(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                LocalDate today = LocalDate.now();
                boolean isPast = bookingDate.isBefore(today);
                boolean isUpcoming = bookingDate.isAfter(today);

                if ("All Bookings".equals(filter) ||
                        ("Past Bookings".equals(filter) && isPast) ||
                        ("Upcoming Bookings".equals(filter) && isUpcoming)) {
                    tableModel.addRow(new Object[]{
                            false, // Default checkbox state
                            booking.getBookingId(),
                            booking.getHallType(),
                            booking.getHallName(),
                            booking.getDate(),
                            booking.getStartTime(),
                            booking.getEndTime(),
                            booking.getStatus(),
                            booking.getPrice()
                    });
                }
            }
        }
    }
    
    public void showPage() {
        a.setVisible(true); // Make the frame visible
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == filterDropdown) {
            filterBookings(); // Filter bookings based on selection
        } else if (e.getSource() == cancelBookingButton) {
            cancelSelectedBooking(); // Cancel the selected booking
        } else if (e.getSource() == raiseIssueButton) {
            raiseIssueForBooking(); // Raise an issue for the selected booking
        }
        else if (e.getSource() == backButton){
            a.setVisible (false);
            customerPage.a.setVisible (true);
        }
    }

    private void cancelSelectedBooking() {
         int selectedRow = getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(a, "Please select a booking to cancel.");
            return;
        }

        String bookingId = (String) tableModel.getValueAt(selectedRow, 1);
        Booking selectedBooking = findBookingById(bookingId);

        if (selectedBooking == null) {
            JOptionPane.showMessageDialog(a, "Booking not found.");
            return;
        }

        LocalDate bookingDate = LocalDate.parse(selectedBooking.getDate(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        LocalDate today = LocalDate.now();
        long daysBetween = ChronoUnit.DAYS.between(today, bookingDate);

        if (daysBetween < 3) {
            JOptionPane.showMessageDialog(a, "Booking can only be cancelled 3 or more days in advance.");
            return;
        }

        // Set the booking status to "Cancelled"
        selectedBooking.setStatus("Cancelled");

        // Update the availability status
        updateAvailability(selectedBooking.getHallName(), selectedBooking.getDate(), selectedBooking.getStartTime(), selectedBooking.getEndTime());

        // Save updated booking data to file
        DataIO.write(); 
        loadBookings(); // Refresh the table data
        JOptionPane.showMessageDialog(a, "Booking cancelled successfully.");
    }

    private void raiseIssueForBooking() {
        int selectedRow = getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(a, "Please select a booking to raise an issue.");
            return;
        }

        String bookingId = (String) tableModel.getValueAt(selectedRow, 1);
        Booking selectedBooking = findBookingById(bookingId);

        if (selectedBooking == null) {
            JOptionPane.showMessageDialog(a, "Booking not found.");
            return;
        }

        String selectedIssue = (String) issueDropdown.getSelectedItem();
        String currentDate = getCurrentDate();
        Issue newIssue = new Issue(bookingId, selectedBooking.getHallName(), customer.getUserid(), selectedIssue, currentDate);

        DataIO.allIssue.add(newIssue); // Add issue to the issue list
        DataIO.write(); // Save the issues to issue.txt
        JOptionPane.showMessageDialog(a, "Issue reported successfully.");
    }

    private Booking findBookingById(String bookingId) {
        for (Booking booking : DataIO.allBooking) {
            if (booking.getBookingId().equals(bookingId)) {
                return booking;
            }
        }
        return null;
    }

    private int getSelectedRow() {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((Boolean) tableModel.getValueAt(i, 0)) {
                return i; // Return the index of the selected row
            }
        }
        return -1; // No row selected
    }

    private String getCurrentDate() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return today.format(formatter);
    }
    
    private void updateAvailability(String hallName, String bookingDate, String startTime, String endTime) {
    // Find the corresponding availability entry
    for (Availability availability : DataIO.allAvailability) {
        if (availability.getHallName().equals(hallName) && 
            availability.getDate().equals(bookingDate) && 
            availability.getStartTime().equals (startTime)&&
            availability.getEndTime().equals (endTime)&&
            availability.getStatus().equals("Booked")) {
            availability.setStatus("Available"); // Update status to "Available"
            break; // Exit loop after updating
        }
    }
    DataIO.write(); // Save changes to availability.txt (implement this method)
}
}
