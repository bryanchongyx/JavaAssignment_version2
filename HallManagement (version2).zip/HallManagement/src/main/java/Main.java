

public class Main {
    public static PageLoginSignIn a1;
    public static PageAdmin a2;
    public static PageRegistrationForm a3;
    public static PageSuperAdmin a4;
    public static PageSchedulerManagement a5;
    public static PageCustomerManagement a6;
    public static PageManagerManagement a7;
    public static PageEditAdminProfile a8;
    public static PageAdminManagement a9;
    public static PageScheduler a10;
    public static PageHallManagement a11;
    public static PageHallScheduling a12;
    public static PageCustomer a13;
    public static PageHallBooking a14;
    public static PageBookingManagement a15;
    public static PageEditCustomerProfile a16;

    public static void main(String[] args) {
        DataIO.read();
        HallAvailabilityUpdater.updateAvailability();
        a1 = new PageLoginSignIn();
    }
}
