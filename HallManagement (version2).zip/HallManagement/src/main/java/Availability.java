public class Availability {
    private String hallType;    // Type of hall (e.g., Auditorium, Banquet Hall)
    private String hallName;    // Name of the hall
    private int capacity;       // Capacity of the hall
    private double ratePerHour; // Hourly rate of the hall
    private String date;        // Date of availability
    private String startTime;   // Start time of availability slot
    private String endTime;     // End time of availability slot
    private String status;      // e.g., "Available", "Booked", "Under Maintenance"
    private Double price;       // Calculated price based on duration and ratePerHour, null if under maintenance

    // Constructor
    public Availability(String hallType, String hallName, int capacity, double ratePerHour, String date, String startTime, String endTime, String status, Double price) {
        this.hallType = hallType;
        this.hallName = hallName;
        this.capacity = capacity;
        this.ratePerHour = ratePerHour;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.price = price;
    }

    // Getters and Setters
    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(double ratePerHour) {
        this.ratePerHour = ratePerHour;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

}
