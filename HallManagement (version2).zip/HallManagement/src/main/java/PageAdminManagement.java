import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PageAdminManagement implements ActionListener {
    JFrame a;
    JButton create, delete, back;
    JTable adminTable;
    DefaultTableModel tableModel;
    PageSuperAdmin superadminPage;

    public PageAdminManagement(PageSuperAdmin superadminPage) {
        this.superadminPage = superadminPage;
        a = new JFrame();
        a.setTitle("Admin Management");
        a.setSize(700, 400);
        a.setLocationRelativeTo(null); // Center the frame on screen
        a.setLayout(new BorderLayout(10, 10)); // Add padding around the frame
        
        // Table Setup
        String[] columnNames = {"Name", "User ID", "Joined Date", "Select"};
        tableModel = new DefaultTableModel(columnNames, 0);
        adminTable = new JTable(tableModel) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 3 ? Boolean.class : String.class;
            }
        };
        loadAdminData();
        adminTable.getTableHeader().setReorderingAllowed(false); // Prevent column reordering

        JScrollPane scrollPane = new JScrollPane(adminTable);

        // Bottom panel for buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        create = new JButton("Create");
        delete = new JButton("Delete");
        back = new JButton("Back");
        
        create.addActionListener(this);
        delete.addActionListener(this);
        back.addActionListener(this);
        
        bottomPanel.add(create);
        bottomPanel.add(delete);
        bottomPanel.add(back);

        // Add components to frame
        a.add(new JLabel("Administrator Management", SwingConstants.CENTER), BorderLayout.NORTH);
        a.add(scrollPane, BorderLayout.CENTER);
        a.add(bottomPanel, BorderLayout.SOUTH);

        a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        a.setVisible(true);
    }

    public void showPage() {
        a.setVisible(true); // Make the frame visible
    }

    // Load admin data into the table
    private void loadAdminData() {
        tableModel.setRowCount(0); // Clear existing data
        for (Admin admin : DataIO.allAdmin) {
            Object[] rowData = {admin.getFullname(), admin.getUserid(), admin.getDate(), false};
            tableModel.addRow(rowData);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == create) {
                try {
                    // Prompt for administrator full name
                    String admin_fullname = JOptionPane.showInputDialog(a, "Enter Administrator Full Name:");
                    if (admin_fullname == null || admin_fullname.trim().isEmpty()) {
                        throw new Exception("Full Name cannot be empty!");
                    }

                    // Prompt for user ID
                    String admin_userid = JOptionPane.showInputDialog(a, "Enter User ID for new administrator:");
                    if (admin_userid == null || admin_userid.trim().isEmpty()) {
                        throw new Exception("User ID cannot be empty!");
                    }
                    if (DataIO.checkUserid(admin_userid.trim()) != null) {
                        throw new Exception("Admin User ID is taken!");
                    }

                    // Prompt for password
                    String admin_password = JOptionPane.showInputDialog(a, "Set Password for new administrator:");
                    if (admin_password == null || admin_password.trim().isEmpty()) {
                        throw new Exception("Password cannot be empty!");
                    }

                    // Create today's date
                    String todayDate = java.time.LocalDate.now().toString();

                    // Create new User and Admin objects
                    User newUser = new User(admin_fullname.trim(), admin_userid.trim(), admin_password.trim(), "administrator");
                    Admin newAdmin = new Admin(admin_fullname.trim(), admin_userid.trim(), admin_password.trim(), todayDate);

                    // Add the new administrator to the lists
                    DataIO.allUser.add(newUser);
                    DataIO.allAdmin.add(newAdmin);

                    // Save changes to files
                    DataIO.write();

                    // Refresh table data
                    loadAdminData();

                    // Show success message
                    JOptionPane.showMessageDialog(a, "New administrator created successfully!");

                } catch (Exception ex) {
                    // Show error message
                    JOptionPane.showMessageDialog(a, ex.getMessage());
                }

            } else if (e.getSource() == delete) {
                // Delete selected administrators
                ArrayList<Admin> adminsToDelete = new ArrayList<>();
                for (int i = 0; i < adminTable.getRowCount(); i++) {
                    boolean isSelected = (boolean) adminTable.getValueAt(i, 3); // Checkbox column
                    if (isSelected) {
                        String userid = (String) adminTable.getValueAt(i, 1); // User ID column
                        Admin adminToDelete = DataIO.findAdminByUserId(userid);
                        if (adminToDelete != null) {
                            adminsToDelete.add(adminToDelete);
                        }
                    }
                }

                if (adminsToDelete.isEmpty()) {
                    JOptionPane.showMessageDialog(a, "No administrators selected for deletion.");
                } else {
                    int confirmation = JOptionPane.showConfirmDialog(a, 
                        "Are you sure you want to delete the selected administrators?", 
                        "Delete Confirmation", JOptionPane.YES_NO_OPTION);

                    if (confirmation == JOptionPane.YES_OPTION) {
                        // Remove selected admins from the list and update the file
                        for (Admin admin : adminsToDelete) {
                            DataIO.allAdmin.remove(admin);
                            DataIO.removeUserByUserId(admin.getUserid());
                        }
                        DataIO.write(); // Save changes to files
                        loadAdminData(); // Refresh table data
                        JOptionPane.showMessageDialog(a, "Selected administrators deleted successfully.");
                    }
                }

            } else if (e.getSource() == back) {
                a.setVisible(false);
                superadminPage.a.setVisible(true); // Show the superadmin page
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(a, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
